use edyoda;

CREATE table Agent
		(EmpID varchar(50),
		 Name varchar(50),
		 Sales int);	
         
CREATE table Manager
		(EmpID varchar(50),
		 Manager varchar(50));	         
         
INSERT INTO agent  values 
	( 'E1001','Ajay',704),
	( 'E1002','Vijay',105),
	( 'E1004','Amar',250),
	( 'E1005','Akbar',350),
	( 'E1009','Anthony',750),
    ( 'E1011','Prem',1000);          
    
    select * from agent;
    
    INSERT INTO Manager  values 
	( 'E1001','TOM'),	( 'E1002','TOM'),	( 'E1003','TOM'),
	( 'E1004','DOM'),	( 'E1005','DOM'),	( 'E1006','DOM'),
	( 'E1007','KOM'),	( 'E1008','KOM'),	( 'E1009','KOM'),	( 'E1010','KOM'); 
    
    select * from Manager;
-------------------------------------------------------
    SELECT A.EMPID , A.NAME, A.SALES , M.MANAGER 
    FROM AGENT AS A
    LEFT JOIN
    MANAGER AS M
    ON A.EMPID  = M.EMPID;
    
    
    
    
----------------------------------------
	SELECT M.EMPID ,M.MANAGER, A.NAME, A.SALES  
	FROM AGENT AS A
    RIGHT JOIN
    MANAGER AS M
    ON A.EMPID  = M.EMPID;
    
 ------------------------------------------
 	SELECT A.EMPID , A.NAME, A.SALES , M.MANAGER 
	FROM AGENT AS A
    INNER JOIN
    MANAGER AS M
    ON A.EMPID  = M.EMPID;
------------------------------------------
SELECT * FROM AGENT AS A 
LEFT OUTER JOIN 
MANAGER AS M
ON A.EMPID = M.EMPID;

SELECT * FROM AGENT AS A 
RIGHT OUTER JOIN 
MANAGER AS M
ON A.EMPID = M.EMPID;
------------------------------------------    
SELECT A.EMPID , A.NAME, A.SALES , M.MANAGER 
FROM AGENT AS A
CROSS JOIN
MANAGER AS M;

------------------------------------------    
SELECT  A.EMPID AS A_EMPID , A.NAME, A.SALES,
B.EMPID AS B_EMPID ,B.NAME, B.SALES
FROM 
AGENT AS A, 
AGENT AS B;
------------------------------------------   


    